import java.awt.*;
import java.applet.*;
public class Namrata extends Applet
{
   	public void paint (Graphics g)
	{
		int  x[ ]={100,300,200};
		int  y[ ]={100,100,50};
		g.drawPolygon(x,y,3);
		g.setColor(Color.blue);
		g.fillPolygon(x,y,3);
		int a[ ]={200,600,600,300};
		int b[ ]={50,50,100,100};
		g.drawPolygon(a,b,4);
		g.setColor(Color.yellow);
		g.fillPolygon(a,b,4);
		int c[ ]={300,600,600,300};
		int d[ ]={100,100,360,360};
		g.drawPolygon(c,d,4);
		g.setColor(Color.red);
		g.fillPolygon(c,d,4);
		int e[ ]={100,300,300,100};
		int f[ ]={100,100,360,360};
		g.drawPolygon(e,f,4);
		g.setColor(Color.green);
		g.fillPolygon(e,f,4);
		g.drawArc(380,150,150,150,180,360);
		g.setColor(Color.white);
		g.fillArc(380,150,150,150,180,360);
		int j[ ]={175,175,225,225};
		int k[ ]={360,200,200,360};
		g.drawPolygon(j,k,4);
		g.setColor(Color.black);
		g.fillPolygon(j,k,4);
		g.drawString("Amit",375,80);

	}

}